function(){
    return {};
}