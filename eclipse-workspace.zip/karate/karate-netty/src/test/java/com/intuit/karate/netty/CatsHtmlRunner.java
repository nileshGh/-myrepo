package com.intuit.karate.netty;

import org.junit.Test;

/**
 *
 * @author pthomas3
 */
public class CatsHtmlRunner {
    
    @Test
    public void testMain() {
        Main.main(new String[]{"src/test/resources"});        
    }    
    
}
