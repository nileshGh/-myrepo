package com.intuit.karate.testng;

import cucumber.api.CucumberOptions;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(tags = {"~@ignore"})
public class KarateTestngTest extends KarateRunner {
    
}
