package com.intuit.karate.testng.smoke;

import com.intuit.karate.testng.KarateRunner;

/**
 *
 * @author pthomas3
 */
public class SmokeRunner extends KarateRunner {
    
}
