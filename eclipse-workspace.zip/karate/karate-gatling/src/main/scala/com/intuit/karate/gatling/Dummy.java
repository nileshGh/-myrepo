package com.intuit.karate.gatling;

public class Dummy {
    // just for the sake of javadoc else maven public release fails
}
