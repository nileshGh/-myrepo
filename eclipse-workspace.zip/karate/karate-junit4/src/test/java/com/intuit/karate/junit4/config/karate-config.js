function() {
  return { defaultoverride: 'worked', baseconfig: 'overridden' };
}
