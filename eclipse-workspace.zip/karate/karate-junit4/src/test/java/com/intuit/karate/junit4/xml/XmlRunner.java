package com.intuit.karate.junit4.xml;

import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public class XmlRunner {

}