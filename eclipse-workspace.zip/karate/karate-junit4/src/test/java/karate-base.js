function() {   
    return { baseconfig: 'loaded' };
}