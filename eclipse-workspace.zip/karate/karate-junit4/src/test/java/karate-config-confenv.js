function() {
  return { confoverride: 'yes' };
}