function() {
  return { confoverride: 'success' };
}