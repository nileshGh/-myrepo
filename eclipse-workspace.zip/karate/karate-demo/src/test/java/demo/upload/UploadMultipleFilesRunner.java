package demo.upload;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author ssishtla
 */
@CucumberOptions(features = "classpath:demo/upload/upload-multiple-files.feature")
public class UploadMultipleFilesRunner extends TestBase {
    
}
