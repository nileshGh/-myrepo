package demo.upload;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author ssishtla
 */
@CucumberOptions(features = "classpath:demo/upload/upload-multiple-fields.feature")
public class UploadMultipleFieldsRunner extends TestBase {
    
}
