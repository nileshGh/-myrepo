package demo.calldynamic;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(features = "classpath:demo/calldynamic/call-dynamic-json.feature")
public class CallDynamicJsonRunner extends TestBase {
    
}
