package demo.loopcall;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(features = "classpath:demo/loopcall/alt-loop.feature")
public class AltLoopCallRunner extends TestBase {
    
}
