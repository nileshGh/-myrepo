package demo.java;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class CatsJavaRunner extends TestBase {
    
}
