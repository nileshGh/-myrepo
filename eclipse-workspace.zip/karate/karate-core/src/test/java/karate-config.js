function() {   
  return { someConfig: 'someValue' }
}