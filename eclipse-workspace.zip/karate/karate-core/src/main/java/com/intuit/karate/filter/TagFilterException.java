package com.intuit.karate.filter;

public class TagFilterException extends Exception {

    public TagFilterException() {
        super();
    }

    public TagFilterException(String message) {
        super(message);
    }
}
