package com.intuit.karate;

/**
 *
 * @author pthomas3
 */
public enum AssignType {
    
    AUTO,
    COPY,
    TEXT,
    YAML,
    JSON,
    STRING,
    XML,
    XML_STRING
    
}
