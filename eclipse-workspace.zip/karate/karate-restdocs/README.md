# Karate Spring REST Docs Integration

## Help Wanted !
Please refer to this ticket for details: [Implement Spring REST Docs Support](https://github.com/intuit/karate/issues/25)

[Spring REST Docs](https://projects.spring.io/spring-restdocs/) would be a great add to Karate and will benefit the community greatly. Especially because of Karate's unique approach where non-programmers can easily create test scripts.

We already have most of the code in place that converts Karate HTTP objects into the form that Spring REST Docs expects. Do consider contributing to make this ready for use !