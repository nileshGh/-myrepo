package junit.test.utils;

import java.util.Locale;

import org.apache.http.Header;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolVersion;
import org.apache.http.StatusLine;
import org.apache.http.params.HttpParams;
import org.json.JSONObject;

import gherkin.JSONParser;
import gherkin.deps.com.google.gson.JsonParser;

public class HttpConfig {
	
	private HttpResponse response = new HttpResponse() {
		
		public void setParams(HttpParams arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public void setHeaders(Header[] arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public void setHeader(String arg0, String arg1) {
			// TODO Auto-generated method stub
			
		}
		
		public void setHeader(Header arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public void removeHeaders(String arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public void removeHeader(Header arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public HeaderIterator headerIterator(String arg0) {
			// TODO Auto-generated method stub
			return null;
		}
		
		public HeaderIterator headerIterator() {
			// TODO Auto-generated method stub
			return null;
		}
		
		public ProtocolVersion getProtocolVersion() {
			// TODO Auto-generated method stub
			return null;
		}
		
		public HttpParams getParams() {
			// TODO Auto-generated method stub
			return null;
		}
		
		public Header getLastHeader(String arg0) {
			// TODO Auto-generated method stub
			return null;
		}
		
		public Header[] getHeaders(String arg0) {
			// TODO Auto-generated method stub
			return null;
		}
		
		public Header getFirstHeader(String arg0) {
			// TODO Auto-generated method stub
			return null;
		}
		
		public Header[] getAllHeaders() {
			// TODO Auto-generated method stub
			return null;
		}
		
		public boolean containsHeader(String arg0) {
			// TODO Auto-generated method stub
			return false;
		}
		
		public void addHeader(String arg0, String arg1) {
			// TODO Auto-generated method stub
			
		}
		
		public void addHeader(Header arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public void setStatusLine(ProtocolVersion arg0, int arg1, String arg2) {
			// TODO Auto-generated method stub
			
		}
		
		public void setStatusLine(ProtocolVersion arg0, int arg1) {
			// TODO Auto-generated method stub
			
		}
		
		public void setStatusLine(StatusLine arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public void setStatusCode(int arg0) throws IllegalStateException {
			// TODO Auto-generated method stub
			
		}
		
		public void setReasonPhrase(String arg0) throws IllegalStateException {
			// TODO Auto-generated method stub
			
		}
		
		public void setLocale(Locale arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public void setEntity(HttpEntity arg0) {
			// TODO Auto-generated method stub
			
		}
		
		public StatusLine getStatusLine() {
			// TODO Auto-generated method stub
			return null;
		}
		
		public Locale getLocale() {
			// TODO Auto-generated method stub
			return null;
		}
		
		public HttpEntity getEntity() {
			// TODO Auto-generated method stub
			return null;
		}
	};

	public HttpResponse getResponse() {
		return response;
	}

	public void setResponse(HttpResponse response) {
		this.response = response;
	}


}
