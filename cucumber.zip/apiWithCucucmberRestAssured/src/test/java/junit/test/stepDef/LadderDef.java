package junit.test.stepDef;



import java.util.List;

import cucumber.api.java.en.Given;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class LadderDef{

	@Given("^I test with restAssured$") 
	public void verifyCbd()  {
		// Specify the base URL to the RESTful web service
		RestAssured.baseURI = "https://api.github.com/events";
 
		// Get the RequestSpecification of the request that you want to sent
		// to the server. The server is specified by the BaseURI that we have
		// specified in the above step.
		RequestSpecification httpRequest = RestAssured.given();
 
		// Make a request to the server by specifying the method Type and the method URL.
		// This will return the Response from the server. Store the response in a variable.
		Response response = httpRequest.request(Method.GET, "");
 
		// Now let us print the body of the message to see what response
		// we have recieved from the server
		String responseBody = response.getBody().asString();
		System.out.println("Response Body is =>  " + responseBody);
		
		JsonPath jsonPathEvaluator = response.jsonPath();
//		String login = jsonPathEvaluator.get("login");
//		System.out.println("login"+login);
		List<String> allBooks = jsonPathEvaluator.getList("id");
		 
		// Iterate over the list and print individual book item
		for(String book : allBooks)
		{
			System.out.println("Book: " + book);
		}
		System.out.println("--------------------------------------");
		List<Integer> ids = jsonPathEvaluator.getList("actor.id");
		 
		// Iterate over the list and print individual book item
		for(Integer id : ids)
		{
			System.out.println("id: " + id);
		}
		List<Integer> idis = jsonPathEvaluator.getList("actor.id>=25044321");
		 
		// Iterate over the list and print individual book item
		for(Integer id : idis)
		{
			System.out.println("id: " + id);
		}
	}
	}	
	
	