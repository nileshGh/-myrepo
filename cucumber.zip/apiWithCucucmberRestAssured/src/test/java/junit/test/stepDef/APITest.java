package junit.test.stepDef;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Locale;

import org.apache.http.Header;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolVersion;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.jayway.restassured.response.Response;

import cucumber.api.java.en.Given;
import junit.framework.TestCase;
import junit.test.utils.HttpConfig;

public class APITest extends HttpConfig {
	
//	   HttpUriRequest request = new HttpGet( "https://api.github.com/users/eugenp" );
	 HttpUriRequest request = new HttpGet( "https://api.github.com/users/eugenp" );

	
	@Given("^I login to site$") 
	public void
	givenRequestWithNoAcceptHeader_whenRequestIsExecuted_thenDefaultResponseContentTypeIsJson()
	  throws ClientProtocolException, IOException {
	  
	   // Given
	   String jsonMimeType = "application/json";
	 
	   // When
	    setResponse(HttpClientBuilder.create().build().execute( request ));
	 
	   // Then
	   String mimeType = ContentType.getOrDefault(getResponse().getEntity()).getMimeType();
	   assertEquals( jsonMimeType, mimeType );
	   
	}

@Given("^I test$") 
public void verifyContent()
	throws ClientProtocolException, IOException {
	CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	HttpGet request1 = new HttpGet("http://192.168.108.239:9080/cbd?userId=MASTER1");
	request1.addHeader("content-type", "application/json");
	request1.addHeader("Authorization","Bearer 00004-T592Jx76Va5XyjTXKQCwo:1c4hlvt6d");
	HttpResponse result = httpClient.execute(request1);
    String json = EntityUtils.toString(result.getEntity(), "UTF-8");
    System.out.println(json);
}	

}
