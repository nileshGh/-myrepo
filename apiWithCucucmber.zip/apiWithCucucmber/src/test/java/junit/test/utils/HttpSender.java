package junit.test.utils;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



public class HttpSender {
	static Object obj;
	private static JSONObject jsonObject;

	public JSONObject getCbdJson(String user) throws ClientProtocolException, IOException, ParseException {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpGet requestForRegion = new HttpGet("http://192.168.108.239:9080/cbd?userId="+user);
//		HttpGet requestForRegion = new HttpPost("http://192.168.109.193:9080/ladder");

		requestForRegion.addHeader("content-type", "application/json");
		requestForRegion.addHeader("Authorization","Bearer 0000yjtG2Cwj1w88JA7sh1TY0-w:1c4hlvt6d");
		HttpResponse result = httpClient.execute(requestForRegion);
	    String jsonForRegion = EntityUtils.toString(result.getEntity(), "UTF-8");
	    System.out.println("Json is"+jsonForRegion);
	    JSONParser parser = new JSONParser();
//	    Object obj;
	    obj = parser.parse(jsonForRegion);
		jsonObject = (JSONObject) obj;
	    System.out.println(getJsonObject());
	 
		return getJsonObject();
	}
	
	public JSONArray getCurrencyJson() throws ClientProtocolException, IOException, ParseException {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpGet requestForRegion = new HttpGet("http://192.168.108.239:9080/ladder/currencies");

		requestForRegion.addHeader("content-type", "application/json");
		requestForRegion.addHeader("Authorization","Bearer 0000yjtG2Cwj1w88JA7sh1TY0-w:1c4hlvt6d");
		HttpResponse result = httpClient.execute(requestForRegion);
	    String jsonForRegion = EntityUtils.toString(result.getEntity(), "UTF-8");
	    System.out.println("Json is"+jsonForRegion);
	    JSONParser parser = new JSONParser();
	    JSONArray objArray;
	    objArray = (JSONArray) parser.parse(jsonForRegion);
//		JSONObject jsonObject = (JSONObject) objArray[0];
	    System.out.println(objArray);
	 
		return objArray;
	}

	public static JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}
	

}
