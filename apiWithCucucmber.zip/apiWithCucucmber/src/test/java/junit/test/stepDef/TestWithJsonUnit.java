package junit.test.stepDef;

import cucumber.api.java.en.Given;
import junit.test.utils.HttpSender;
import junit.test.utils.JsonFluentAssert;
import static net.javacrumbs.jsonunit.JsonAssert.*;
import static net.javacrumbs.jsonunit.core.Option.*;

public class TestWithJsonUnit extends HttpSender {

	
	@Given("^I test with jsonUnit$") 
	public void verifyCbd()  {
		// compares two JSON documents
		assertJsonEquals("{\"test\":1}", "{\n\"test\": 1\n}");
		
//		JSONObject jsonObject =  
		// objects are automatically serialized before comparison
//		assertJsonEquals(jsonObject, "{\n\"test\": 1\n}");

		// compares only part
		assertJsonPartEquals("2", "{\"test\":[{\"value\":1},{\"value\":2}]}",
		    "test[1].value");
		    
		// extra options can be specified
		assertJsonEquals("{\"test\":{\"a\":1}}",
		    "{\"test\":{\"a\":1, \"b\": null}}",
		    when(TREATING_NULL_AS_ABSENT));

		// compares only the structure, not the values
//		assertJsonEquals("[{\"test\":1}, {\"test\":2}]",
//		    "[{\n\"test\": 1\n}, {\"TEST\": 4}]", when(IGNORING_VALUES));

		// Lenient parsing of expected value
		assertJsonEquals("{//Look ma, no quotation marks\n test:'value'}", 
		    "{\n\"test\": \"value\"\n}");
		
		assertJsonEquals("{\"test\":\"${json-unit.ignore}\"}",
			    "{\n\"test\": {\"object\" : {\"another\" : 1}}}");
		
//		assertJsonEquals(
//			     "{\"root\":{\"test\":1, \"ignored\": 2}}", 
//			     "{\"root\":{\"test\":1, \"ignored\": 1}}", 
//			     whenIgnoringPaths("root.ignored")
//			);
		 
	}	
	
}
