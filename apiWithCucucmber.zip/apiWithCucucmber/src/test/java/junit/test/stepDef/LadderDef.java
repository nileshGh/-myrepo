package junit.test.stepDef;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Iterator;
import org.apache.http.client.ClientProtocolException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import cucumber.api.java.en.Given;
import junit.test.utils.HttpSender;
import static net.javacrumbs.jsonunit.JsonAssert.*;
import static net.javacrumbs.jsonunit.core.Option.*;

public class LadderDef extends HttpSender {
	@Given("^I send the request to get cdb and region for user \"([^\"]*)\"")
	public void getCbd(String arg1) throws ClientProtocolException, IOException, ParseException {
		getCbdJson("MASTER1");
	}

	@Given("^I verify \"([^\"]*)\" is current date$") 
	public void verifyCbd(String arg1) throws ClientProtocolException, IOException, ParseException {
		 assertEquals( arg1, HttpSender.getJsonObject().get("cbd") );
		 
		 assertJsonEquals("{\"cbd\":\"2017-09-23\",\"region\":\"TESTHSS\"}",
				 "{\"cbd\":\"2017-09-23\",\"region\":\"TESTHSS\"}",when(IGNORING_ARRAY_ORDER));
		 assertJsonEquals("{\"test\":[{\"TEST\":\"TEST\"},1,2,3]}",
                 "{\"test\":  [{\"TEST\":\"TEST\"},1,2,3]}");
		 assertJsonEquals("{\"test\":[1,2,3]}",
                 "{\"test\":  [3,2,1]}",when(IGNORING_ARRAY_ORDER));
		 assertJsonEquals("{\"test\":[1,2,3]}",
                 "{\"test\":  [1,3,2]}",when(IGNORING_ARRAY_ORDER));
		 assertJsonEquals("{\"region\":\"TESTHSS\",\"cbd\":\"2017-09-23\"}",
				 "{\"cbd\":\"2017-09-23\",\"region\":\"TESTHSS\"}, when(IGNORING_ARRAY_ORDER)");
			assertJsonEquals("{\"test\":\"${json-unit.ignore}\"}",
				    "{\n\"test\": {\"object\" : {\"another\" : 1}}}");
	}	
	

	@Given("^I verify ignore order of json elements$") 
	public void verifyIgnoreCase() throws ClientProtocolException, IOException, ParseException {
		 
		 assertJsonEquals("{\"cbd\":\"2017-09-23\",\"region\":\"TESTHSS\"}",
				 "{\"cbd\":\"2017-09-23\",\"region\":\"TESTHSS\"}",when(IGNORING_ARRAY_ORDER));
		 assertJsonEquals("{\"test\":[{\"TEST\":\"TEST\"},1,2,3]}",
                 "{\"test\":  [{\"TEST\":\"TEST\"},1,2,3]}");
		 assertJsonEquals("{\"test\":[1,2,3]}",
                 "{\"test\":  [3,2,1]}",when(IGNORING_ARRAY_ORDER));
		 assertJsonEquals("{\"test\":[1,2,3]}",
                 "{\"test\":  [1,3,2]}",when(IGNORING_ARRAY_ORDER));
		 assertJsonEquals("{\"region\":\"TESTHSS\",\"cbd\":\"2017-09-23\"}",
				 "{\"cbd\":\"2017-09-23\",\"region\":\"TESTHSS\"}, when(IGNORING_ARRAY_ORDER)");
			assertJsonEquals("{\"test\":\"${json-unit.ignore}\"}",
				    "{\n\"test\": {\"object\" : {\"another\" : 1}}}");
	}	
	


	@Given("^I verify ([^\"]*) is \"([^\"]*)\"$") 
	public void verifyRegion(String arg2, String arg1) throws ClientProtocolException, IOException, ParseException {
		 assertEquals( arg1, HttpSender.getJsonObject().get(arg2) );		
	}	
	
	
	@Given("^I verify currency$") 
	public void verifyCurrency() throws ClientProtocolException, IOException, ParseException {
		JSONArray newObject = getCurrencyJson();
		Iterator i = newObject.iterator();
		
		 while (i.hasNext()) {
             JSONObject innerObj = (JSONObject) i.next();
             System.out.println("Name "+ innerObj.get("name") +
                     " with decimalPlaces " + innerObj.get("decimalPlaces"));
             
             
         }	
	}	
}
