package junit.test.stepDef;

import cucumber.api.java.en.Given;
import net.javacrumbs.jsonunit.core.Option;
import static net.javacrumbs.jsonunit.JsonMatchers.*;
import static org.junit.Assert.*;

public class HamcrestsMachers {
	
	@Given("^I test with hamcrest macher$") 
	public void verifyJsonWithHamcrest()  {
		assertThat("{\"test\":1}", jsonEquals("{\"test\": 1}"));
		assertThat("{\"test\":1}", jsonPartEquals("test", 1));
		assertThat("{\"test\":[1, 2, 3]}", jsonPartEquals("test[0]", 1));

		assertThat("{\"test\":{\"a\":1, \"b\":2, \"c\":3}}",
		    jsonEquals("{\"test\":{\"b\":2}}").when(Option.IGNORING_EXTRA_FIELDS));

		// Can use other Hamcrest matchers too
//		assertThat("{\"test\":1}", jsonPartMatches("test", is(valueOf(1))));

	}	

}
