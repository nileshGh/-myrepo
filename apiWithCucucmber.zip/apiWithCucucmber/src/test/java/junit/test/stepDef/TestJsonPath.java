package junit.test.stepDef;


import static net.javacrumbs.jsonunit.JsonAssert.assertJsonEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import org.apache.http.client.ClientProtocolException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Test;

import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.google.common.reflect.TypeToken;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

import cucumber.api.java.en.Given;
import gherkin.deps.com.google.gson.Gson;
import junit.test.utils.HttpSender;
import net.javacrumbs.jsonunit.JsonAssert;
import net.javacrumbs.jsonunit.JsonAssert.*;

public class TestJsonPath extends HttpSender{
	String json = "{ \"store\": {\r\n" + 
	 		"    \"book\": [ \r\n" + 
	 		"      { \"category\": \"reference\",\r\n" + 
	 		"        \"author\": \"Nigel Rees\",\r\n" + 
	 		"        \"title\": \"Sayings of the Century\",\r\n" + 
	 		"        \"price\": 8.95\r\n" + 
	 		"      },\r\n" + 
	 		"      { \"category\": \"fiction\",\r\n" + 
	 		"        \"author\": \"Evelyn Waugh\",\r\n" + 
	 		"        \"title\": \"Sword of Honour\",\r\n" + 
	 		"        \"price\": 12.99\r\n" + 
	 		"      },\r\n" + 
	 		"      { \"category\": \"fiction\",\r\n" + 
	 		"        \"author\": \"Herman Melville\",\r\n" + 
	 		"        \"title\": \"Moby Dick\",\r\n" + 
	 		"        \"isbn\": \"0-553-21311-3\",\r\n" + 
	 		"        \"price\": 8.99\r\n" + 
	 		"      },\r\n" + 
	 		"      { \"category\": \"fiction\",\r\n" + 
	 		"        \"author\": \"J. R. R. Tolkien\",\r\n" + 
	 		"        \"title\": \"The Lord of the Rings\",\r\n" + 
	 		"        \"isbn\": \"0-395-19395-8\",\r\n" + 
	 		"        \"price\": 22.99\r\n" + 
	 		"      }\r\n" + 
	 		"    ],\r\n" + 
	 		"    \"bicycle\": {\r\n" + 
	 		"      \"color\": \"red\",\r\n" + 
	 		"      \"price\": 19.95\r\n" + 
	 		"    }\r\n" + 
	 		"  }\r\n" + 
	 		"}";
	@Given("^book author at json path \"([^\"]*)\" should be \"([^\"]*)\"$") 
	public void verifyCbd(String arg1,String arg2) throws ClientProtocolException, IOException, ParseException {
	
		System.out.println("Third book is"+JsonPath.read(json, arg1).toString());
		List<String> authorName= JsonPath.read(json, arg1);
		System.out.println(authorName);
		assertEquals(arg2, authorName.get(0));
	}
	
	@Given("^length of book at json path \"([^\"]*)\" should be \"([^\"]*)\"$") 
	public void verifyLength(String arg1,String arg2) throws ClientProtocolException, IOException, ParseException {
		DocumentContext context = JsonPath.parse(json);
	    int length = context.read(arg1);
	    System.out.println("test"+length);
		assertEquals(Integer.parseInt(arg2), length);
	}
	
	@Given("^authors of book at json path \"([^\"]*)\" should be \"([^\"]*)\"$") 
	public void verifyAuthors(String arg1,List<String> arg2) throws ClientProtocolException, IOException, ParseException {
		DocumentContext context = JsonPath.parse(json);
		List<String> authorName = context.read(arg1);
	    System.out.println("test"+authorName);
		assertEquals(arg2, authorName);
	}
	
	@Given("^test for ignore keys$") 
	public void verifyIgnoreCase() throws ClientProtocolException, IOException, ParseException {
		assertJsonEquals("{\"test\":\"${json-unit.ignore}\",\"te\":\"sdf\"}",
			    "{\n\"test\": {\"object\" : {\"another\" : 1}},\"te\":\"sdf\"}");
	}
	
	@Given("^I compare actual with template file \"([^\"]*)\"$") 
	public void compareWithTemplate(String arg1) throws ClientProtocolException, IOException, ParseException {
		try {
		       JSONParser parser = new JSONParser();
		        Object object = parser
		                .parse(new FileReader(arg1));
		        
		        //convert Object to JSONObject
		        JSONObject jsonObject = (JSONObject)object;
		        String json1=jsonObject.toJSONString();
		        String json2="{\"Countries\":[\"India\",\"England\",\"Ausftralia\"],\"Age\":9d99,\"Name\":\"www.javainterviewpoint.com\"}";
		        System.out.println("json"+jsonObject);
		        Gson g = new Gson();
				  Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
				  Map<String, Object> firstMap = g.fromJson(json1, mapType);
				  Map<String, Object> secondMap = g.fromJson(json2, mapType);
				  System.out.println("Difference is "+Maps.difference(firstMap, secondMap));
				  MapDifference<String, Object> ab = Maps.difference(firstMap, secondMap);
				  System.out.println("Difference is "+ab);
				assertJsonEquals(jsonObject,
					    "{\"Countries\":[\"India\",\"England\",\"Australia\"],\"Age\":999,\"Name\":\"www.javainterviewpoint.com\"}");
			      assertEquals(ab.toString(), firstMap, secondMap);


		
			
		} catch (AssertionError e) {
			System.out.println("-------------->error is "+e);
			throw e;
			
		}
	}
		
	@Given("^I compare actual ladder with template file \"([^\"]*)\" \"([^\"]*)\"$") 
	public void compareLaddderWithTemplate(String arg1, String arg2) throws ClientProtocolException, IOException, ParseException {
		try {
		       JSONParser parser = new JSONParser();
		        Object object1 = parser
		                .parse(new FileReader(arg1));
		        Object object2 = parser
		                .parse(new FileReader(arg2));
		        //convert Object to JSONObject
		        JSONObject jsonObject1 = (JSONObject)object1;
		        JSONObject jsonObject2 = (JSONObject)object2;
		        String json1=jsonObject1.toJSONString();
		        String json2=jsonObject2.toJSONString();
		        System.out.println("json"+jsonObject1);
		        Gson g = new Gson();
				  Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
				  Map<String, Object> firstMap = g.fromJson(json1, mapType);
				  Map<String, Object> secondMap = g.fromJson(json2, mapType);
				  System.out.println("Difference is "+Maps.difference(firstMap, secondMap));
				  MapDifference<String, Object> ab = Maps.difference(firstMap, secondMap);
				  System.out.println("Difference is "+ab);
				  assertEquals(ab.toString(), firstMap, secondMap);


		
			
		} catch (AssertionError e) {
			System.out.println("-------------->error is "+e);
				throw e;
				
			}
 
	}
}
